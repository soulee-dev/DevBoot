---
name: Develop with PyMyRepl
description: Develop with PyMyRepl enviornment.
tags: [local, docker]
icon: /icon/database.svg
---

# PyMyRepl

This template includes python:3.11, MySQL 8.1
